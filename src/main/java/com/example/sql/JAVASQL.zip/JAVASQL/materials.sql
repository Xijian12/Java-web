/*
 Navicat Premium Data Transfer

 Source Server         : mysql_connect
 Source Server Type    : MySQL
 Source Server Version : 80035
 Source Host           : localhost:3306
 Source Schema         : test

 Target Server Type    : MySQL
 Target Server Version : 80035
 File Encoding         : 65001

 Date: 16/01/2024 22:21:18
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for materials
-- ----------------------------
DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials`  (
  `material_id` int(0) NOT NULL AUTO_INCREMENT,
  `school` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `major` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `material_grade` int(0) NOT NULL,
  `material_download_num` int(0) NULL DEFAULT 0,
  `material_click_num` int(0) NULL DEFAULT 0,
  `material_uploader` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `material_profile` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `material_cover_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `material_cover_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `elec_book_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `teaching_plan_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `class_ppt_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `calendar_volume_uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `another_material_uuid` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `elec_book_points` int(0) NULL DEFAULT 0,
  `teaching_plan_points` int(0) NULL DEFAULT 0,
  `class_ppt_points` int(0) NULL DEFAULT 0,
  `calendar_volume_points` int(0) NULL DEFAULT 0,
  `another_material_points` int(0) NULL DEFAULT 0,
  `create_time` datetime(0) NULL DEFAULT NULL,
  `update_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`material_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 53 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of materials
-- ----------------------------
INSERT INTO `materials` VALUES (18, '上海最菜大学', '计算机', '算法设计', 0, 0, 0, 'yhempr@gmail.com', '垃圾课程', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 6, 7, 5, 5, 3, '2024-01-10 15:15:39', '2024-01-10 15:15:39');
INSERT INTO `materials` VALUES (19, '上海最菜大学', '通信', '算法设计', 0, 0, 0, 'yhempr@gmail.com', '垃圾课程', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 6, 7, 5, 5, 3, '2024-01-10 15:33:08', '2024-01-10 15:33:08');
INSERT INTO `materials` VALUES (20, '北京最菜大学', '计算机', '算法设计', 0, 0, 0, 'yhempr@gmail.com', '垃圾课程', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 6, 7, 5, 5, 3, '2024-01-10 16:41:47', '2024-01-10 16:41:47');
INSERT INTO `materials` VALUES (21, '上海最菜大学', '人工智能', '算法设计', 0, 0, 0, 'yhempr@gmail.com', '真是垃圾课程', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (22, '北京最强大学', '软件工程', '人工智能', 5, 0, 0, 'yhempr@gmail.com', '这门课程太有趣了', NULL, NULL, 'Material/df876b28-5c5b-4c85-84e2-d3c193485ddb.txt', NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (23, '南京最牛大学', '电子商务', '市场营销', 1, 0, 0, 'yhempr@gmail.com', '无聊至极', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (24, '广州最受欢迎大学', '通信工程', '网络技术', 4, 0, 0, 'yhempr@gmail.com', '很实用的课程', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (25, '上海最佳大学', '计算机科学', '数据库', 5, 0, 0, '2323223@qq.com', '非常实用的数据库课程', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (26, '武汉最古老大学', '历史学', '中国古代史', 4, 0, 0, '2323223@qq.com', '很有趣的历史学课程', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (27, '重庆最具特色大学', '文学', '现代诗歌', 4, 0, 0, '2323223@qq.com', '让人感慨良多的文学课', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (28, '南宁最和谐大学', '心理学', '人格心理学', 5, 0, 0, '2323223@qq.com', '非常有深度的心理学课', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (29, '杭州最宜居大学', '环境科学', '生态学', 4, 0, 0, '2323223@qq.com', '关注环境问题的重要课程', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (30, '哈尔滨最寒冷大学', '气象学', '气候变化', 3, 0, 0, '2323223@qq.com', '研究气象学的好地方', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (31, '西安最有历史感大学', '考古学', '古代文明', 5, 0, 0, '2031282938@qq.com', '深度挖掘古代文明的好课', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (32, '苏州最具园林特色大学', '园林学', '园林设计', 4, 0, 0, '2031282938@qq.com', '学习园林设计的理想地', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (33, '南昌最有活力大学', '体育学', '体育管理', 4, 0, 0, '2031282938@qq.com', '关注体育行业的好选择', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (34, '济南最山东大学', '地理信息科学', 'GIS技术', 5, 0, 0, '2031282938@qq.com', '地理信息科学的前沿课程', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (35, '长沙最美风景大学', '旅游管理', '旅游规划', 4, 0, 0, '2031282938@qq.com', '规划旅游的重要环节', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (36, '天津最有创意大学', '设计学', '平面设计', 4, 0, 0, 'hyg3146624068@163.com', '培养创意设计能力的专业', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (37, '成都最有活力大学', '生命科学', '遗传学', 4, 0, 0, 'hyg3146624068@163.com', '研究生命科学的好地方', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (38, '深圳最繁荣大学', '经济学', '国际贸易', 4, 0, 0, 'hyg3146624068@163.com', '学习国际贸易的理想学府', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (39, '西宁最宜居大学', '环境工程', '环保科学', 5, 0, 0, 'hyg3146624068@163.com', '深入学习环保科学的好地方', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (40, '南阳最有历史感大学', '考古学', '文物保护', 5, 0, 0, 'hyg3146624068@163.com', '研究文物保护的好地方', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (41, '青岛最有创意大学', '艺术设计', '平面设计', 4, 0, 0, 'hyg3146624068@163.com', '培养创意设计能力的专业', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (42, '合肥最适合生活大学', '城市规划', '城市设计', 4, 0, 0, 'myhsnd666@gmail.com', '学习城市规划的理想学府', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (43, '哈尔滨最有文化底蕴大学', '文学', '中国现当代文学', 5, 0, 0, 'myhsnd666@gmail.com', '深入研究中国现当代文学的好地方', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (44, '昆明最美风景大学', '旅游管理', '自然风景摄影', 4, 0, 0, 'myhsnd666@gmail.com', '学习自然风景摄影的理想学府', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (45, '厦门最宜居大学', '土木工程', '建筑设计', 4, 0, 0, '851314610@qq.com', '深入学习建筑设计的好地方', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (46, '兰州最有特色大学', '民族学', '少数民族文化', 4, 0, 0, '851314610@qq.com', '深入研究少数民族文化的好地方', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (47, '宁波最繁荣大学', '工商管理', '市场营销', 4, 0, 0, '851314610@qq.com', '深入学习市场营销的好地方', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (48, '太原最适合生活大学', '公共管理', '政府管理', 5, 0, 0, '851314610@qq.com', '深入学习政府管理的好地方', NULL, NULL, 'Books/ffbb25ca-b1b8-4709-8c5e-bd1424ce2d72.txt', NULL, NULL, NULL, NULL, 6, 7, 5, 5, 3, '2024-01-10 19:09:44', '2024-01-10 19:09:44');
INSERT INTO `materials` VALUES (49, '北京最菜大学', '计算机', '算法设计', 0, 0, 0, 'yhempr@gmail.com', '垃圾课程', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', NULL, 6, 7, 5, 5, 0, '2024-01-10 16:41:47', '2024-01-11 21:23:52');
INSERT INTO `materials` VALUES (50, '北京最菜大学', '计算机', '算法设计', 0, 0, 0, 'hyg3146624068@163.com', '垃圾课程', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 6, 7, 5, 5, 3, '2024-01-13 19:55:45', '2024-01-13 19:55:45');
INSERT INTO `materials` VALUES (51, '北京最菜大学', '计算机', '算法设计', 0, 0, 0, 'hyg3146624068@163.com', '垃圾课程', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 6, 7, 5, 5, 3, '2024-01-13 19:56:57', '2024-01-13 19:56:57');
INSERT INTO `materials` VALUES (52, '北京最菜大学', '计算机', '算法设计', 0, 0, 0, 'hyg3146624068@163.com', '垃圾课程', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Cover/7226388f-2e29-4dca-be34-9c4011c142a3.jpg', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 'Material/7226388f-2e29-4dca-be34-9c4011c142a3.ZIP', 6, 7, 5, 5, 3, '2024-01-13 19:57:37', '2024-01-13 19:57:37');

SET FOREIGN_KEY_CHECKS = 1;
